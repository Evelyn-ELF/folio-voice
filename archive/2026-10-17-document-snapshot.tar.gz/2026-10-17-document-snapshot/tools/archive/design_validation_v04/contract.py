"""修复契约的可执行设计模型；不是应用服务或真实质量检测器。

输入为已规范化的内存记录，顺序代表服务端追加序号。
不提供身份认证、持久化、HTTP验证或真实音频检测。
"""
from dataclasses import dataclass
from collections.abc import Iterable, Mapping


@dataclass(frozen=True)
class Evidence:
    gate: str
    digest: str
    scope: str
    actor: str
    passed: bool


def closure_errors(
    state: str, digest: str, scope: str, evidence: Iterable[Evidence],
    confirmed: bool, blockers: int,
) -> set[str]:
    """返回不能关闭的原因；同门槛有效记录以最后一次为准。"""
    errors = set()
    if state != 'awaiting_device':
        errors.add('state')
    if not confirmed:
        errors.add('confirmation')
    if blockers != 0:
        errors.add('blockers')
    latest = {}
    for record in evidence:
        if record.digest != digest or record.scope != scope:
            continue
        if record.gate in {'Q3', 'Q5'} and record.actor != 'human':
            continue
        latest[record.gate] = record.passed
    errors.update(gate for gate in ('Q1', 'Q2', 'Q3', 'Q4', 'Q5')
                  if not latest.get(gate, False))
    return errors


def invalidated(changed: set[str], edges: Mapping[str, set[str]]) -> set[str]:
    """按实际依赖求失效闭包；拒绝未知节点及环，避免少修或无限遍历。"""
    nodes = set(edges).union(*(set(v) for v in edges.values()))
    if not changed <= nodes:
        raise ValueError('变更节点未登记，必须先完善依赖清单')
    pending = {node: 0 for node in nodes}
    for children in edges.values():
        for child in children:
            pending[child] += 1
    ready = [node for node, count in pending.items() if count == 0]
    visited = 0
    while ready:
        node = ready.pop()
        visited += 1
        for child in edges.get(node, set()):
            pending[child] -= 1
            if pending[child] == 0:
                ready.append(child)
    if visited != len(nodes):
        raise ValueError('制品依赖必须是有向无环图')
    affected = set(changed)
    frontier = list(changed)
    while frontier:
        for child in edges.get(frontier.pop(), set()):
            if child not in affected:
                affected.add(child)
                frontier.append(child)
    return affected
