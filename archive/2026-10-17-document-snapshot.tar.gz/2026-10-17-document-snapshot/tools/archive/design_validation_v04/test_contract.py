"""自写场景验证修复契约；不使用真实书籍或音频。"""
import unittest
from contract import Evidence, closure_errors, invalidated


class RepairContractTests(unittest.TestCase):
    def evidence(self):
        return [Evidence(gate, 'new', 'chapter', 'human' if gate in {'Q3', 'Q5'} else 'tool', True)
                for gate in ('Q1', 'Q2', 'Q3', 'Q4', 'Q5')]

    def test_complete_candidate_can_close(self):
        self.assertEqual(closure_errors('awaiting_device', 'new', 'chapter', self.evidence(), True, 0), set())

    def test_each_missing_gate_blocks_closure(self):
        for gate in ('Q1', 'Q2', 'Q3', 'Q4', 'Q5'):
            with self.subTest(gate=gate):
                records = [e for e in self.evidence() if e.gate != gate]
                self.assertIn(gate, closure_errors('awaiting_device', 'new', 'chapter', records, True, 0))

    def test_old_file_or_wrong_scope_cannot_supply_evidence(self):
        for digest, scope in [('old', 'chapter'), ('new', 'other')]:
            with self.subTest(digest=digest, scope=scope):
                records = [Evidence(e.gate, digest, scope, e.actor, True) for e in self.evidence()]
                self.assertEqual(closure_errors('awaiting_device', 'new', 'chapter', records, True, 0), {'Q1', 'Q2', 'Q3', 'Q4', 'Q5'})

    def test_automatic_checks_cannot_replace_human_review(self):
        records = [Evidence(e.gate, e.digest, e.scope, 'tool', True) for e in self.evidence()]
        self.assertEqual(closure_errors('awaiting_device', 'new', 'chapter', records, True, 0), {'Q3', 'Q5'})

    def test_failure_revokes_previous_pass(self):
        records = self.evidence() + [Evidence('Q5', 'new', 'chapter', 'human', False)]
        self.assertIn('Q5', closure_errors('awaiting_device', 'new', 'chapter', records, True, 0))

    def test_retest_pass_can_supersede_failure(self):
        records = self.evidence() + [Evidence('Q5', 'new', 'chapter', 'human', False), Evidence('Q5', 'new', 'chapter', 'human', True)]
        self.assertEqual(closure_errors('awaiting_device', 'new', 'chapter', records, True, 0), set())

    def test_unconfirmed_user_or_blocking_defects_prevent_close(self):
        self.assertIn('confirmation', closure_errors('awaiting_device', 'new', 'chapter', self.evidence(), False, 0))
        self.assertIn('blockers', closure_errors('awaiting_device', 'new', 'chapter', self.evidence(), True, 1))

    def test_unlocated_issue_cannot_close(self):
        self.assertIn('state', closure_errors('awaiting_location', 'new', 'chapter', self.evidence(), True, 0))

    def test_text_change_invalidates_context_and_chapter_not_other_chapter(self):
        edges = {'text': {'block_a', 'block_b'}, 'block_a': {'track'}, 'block_b': {'track'}, 'track': {'alignment', 'Q2', 'Q3'}, 'alignment': {'package'}, 'package': {'Q4', 'Q5'}, 'other_text': {'other_track'}}
        self.assertEqual(invalidated({'text'}, edges), {'text', 'block_a', 'block_b', 'track', 'alignment', 'Q2', 'Q3', 'package', 'Q4', 'Q5'})

    def test_cover_change_preserves_audio_review(self):
        self.assertEqual(invalidated({'cover'}, {'cover': {'package'}, 'track': {'package', 'Q3'}, 'package': {'Q4', 'Q5'}}), {'cover', 'package', 'Q4', 'Q5'})

    def test_unknown_change_is_not_silently_ignored(self):
        with self.assertRaises(ValueError):
            invalidated({'unknown'}, {'text': {'track'}})

    def test_dependency_cycle_is_rejected(self):
        with self.assertRaises(ValueError):
            invalidated({'text'}, {'text': {'track'}, 'track': {'text'}})


if __name__ == '__main__':
    unittest.main()
