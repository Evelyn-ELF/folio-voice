# 核心设计契约

版本0.1，2026-10-17。依据JSON Schema Draft 2020-12（S29），对象均拒绝未知字段。`core.schema.json`包含AgentDecision、Evidence、ResolveCommand、ReleaseCommand、CandidateSelection及基础类型；`examples.json`是自写正反例，无私人资料。

这些是核心边界的机器可读设计，不是已运行API或完整领域模型。完整OpenAPI/物理迁移由台账F03接续，服务行为由F04/F07验证。

必须在应用中补充的语义校验：UUID归属与授权、快照/规则版本一致、起止采样点及同采样率、证据附件真实存在、风险覆盖区间并集、计划步骤ID唯一/前序完整、plan_revision单调、首轮计划非空、run_detector的binding_id为检测器、submit_repair的binding_id为批准预设、compare_stages至少两个且同一范围、成本与修复上限、资格有效性。Schema通过不解除这些约束。

请求中的actor/权限和pass字段不被接受；Evidence是服务端内部生成对象，不是允许Agent创建的HTTP请求体。结构化模型输出适配器可使用供应商支持的Schema子集，但适配后必须用完整领域Schema再次校验，不为迎合供应商删除业务约束。

有效样例只证明结构合法，不代表其自写UUID具有实际授权、质量或真实性。复现校验环境/命令和结果见`../validation/设计补齐核查报告.md`；临时校验环境不作为产品依赖锁。
